function [hexImgsSegmentd,nClasses,time,nEdges,szSegmsQs]=...
srmHex12SobelBd(HexIm,Qlevels,g,minSZ,W1,mHex,nHex,HexIJ2C,B1,B2,Bd)

tic%Stat. Region Merging by a hexagonal lattice, Q large many segments
[HexDeriv,HexEdgeAB,nEdges]=Hex12Derivatives(HexIm,W1,mHex,nHex,HexIJ2C,B1,B2);
[~,index]=sort(HexDeriv);nQ=numel(Qlevels);nPixels=length(HexIm);
hexImgsSegmentd=cell(nQ,1);A=[1:nPixels]';treerank=zeros(nPixels,1);
szSegms=ones(nPixels,1);imSeg1=HexIm(:,1);imSeg2=HexIm(:,2);
imSeg3=HexIm(:,3);nClasses=zeros(1,nQ);
logdelta=2*log(6*nPixels);imFinalHex=zeros(nPixels,1);nCl=nPixels;
for Q=Qlevels
    iter=find(Q==Qlevels);
    for i=1:nEdges
        C1=HexEdgeAB(index(i),1);C2=HexEdgeAB(index(i),2);
        while (A(C1)~=C1 ); C1=A(C1); end
        while (A(C2)~=C2 ); C2=A(C2); end
        % Compute the predicate, region merging test
        dR=(imSeg1(C1)-imSeg1(C2))^2;
        dG=(imSeg2(C1)-imSeg2(C2))^2;dB=(imSeg3(C1)-imSeg3(C2))^2;        
        dev=g^2*logdelta*(1/szSegms(C1)+1/szSegms(C2))/(2*Q);                
        predicat=( (dR<dev) & (dG<dev) & (dB<dev) );               
   if (((C1~=C2)&predicat&(nCl>Bd))|szSegms(C1)<=minSZ|szSegms(C2)<=minSZ)
            if treerank(C1)>treerank(C2)%Find the new root for both regions
                A(C2) = C1; reg=C1;regNot=C2;
            elseif treerank(C1) < treerank(C2)
                A(C1) = C2; reg=C2;regNot=C1;
            elseif C1 ~= C2
                A(C2) = C1; reg=C1;regNot=C2;
                treerank(C1) = treerank(C1) + 1;
            end
            if C1~=C2% Merge regions
                nreg=szSegms(C1)+szSegms(C2);nCl=nCl-1;
            imSeg1(reg)=(szSegms(C1)*imSeg1(C1)+szSegms(C2)*imSeg1(C2))/nreg;
            imSeg2(reg)=(szSegms(C1)*imSeg2(C1)+szSegms(C2)*imSeg2(C2))/nreg;
            imSeg3(reg)=(szSegms(C1)*imSeg3(C1)+szSegms(C2)*imSeg3(C2))/nreg;
            szSegms(reg)=nreg;nClasses(1,iter)=nClasses(1,iter)+1;
            szSegms(regNot)=0;
            end
        end
    end    
    while 1
        map_ = A(A) ;
        if isequal(map_,A) ; break ; end
        A = map_ ;
    end
imFinalHex(:,1)=imSeg1(A);imFinalHex(:,2)=imSeg2(A);
imFinalHex(:,3)=imSeg3(A);hexImgsSegmentd{iter}=imFinalHex;%maps{iter}=A;
szSegmsOutput=szSegms(:);szSegmsOutput=nonzeros(szSegmsOutput);
szSegmsQs{iter}=szSegmsOutput';
end%end for Q=Qlevels
for t=iter:-1:1,%t=iter:-1:2,
    tSum=0;
    for j=1:t,
    tSum=tSum+nClasses(1,j);
    end
    nClasses(1,t)=tSum;
end
nClasses=nPixels-nClasses;
time=toc;%End of the function srmHex;  nPixelsAndEdgesHex=[nPixels,nEdges];