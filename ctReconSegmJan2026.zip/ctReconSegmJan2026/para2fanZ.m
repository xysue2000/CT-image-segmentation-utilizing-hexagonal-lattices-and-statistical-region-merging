function [F,ogamma,otheta] = para2fanZ(P,d,FanSensorSpacing,...
FanRotationIncrement,FanSensorGeometry,FanCoverage,...
ParallelCoverage,interp);%ParallelCoverage='halfcycle'; P=[185,180];d=SOD
dthetaDeg  = FanRotationIncrement;% szP1=size(P);  185   180
[P,m] = padToOddDim(P);%PszPadedRadon=size(P)=[187, 180], m=187
ParallelSensorSpacing=1;%Default
dploc=ParallelSensorSpacing;
ploc=formPlocVectorPara2fanZ(m,dploc);%ploc=dploc*(-m2cn:m2cp)=[-93,93];
fanSpacing = FanSensorSpacing;%Default 1 degree arc
gammaRad=formGammaVectorPara2fanZ(ploc,d,fanSpacing,FanSensorGeometry);
gammaDeg=gammaRad*180/pi;%=[-68, 68] with sz [1,137]
gammaMax=max(gammaDeg);gammaMin=min(gammaDeg);n=size(P,2);%180,   360
[pthetaDeg,dpthetaDeg]=formPthetaVectorPara2fanZ(n,ParallelCoverage);
% pthetaDeg=0:179;dpthetaDeg=1;%pthetaDeg=0:0.5:179.5;dpthetaDeg=0.5;
if strcmp(FanCoverage,'minimal'),
  thetaDeg=formMinimalThetaVectorPara2fanZ(n,dthetaDeg,gammaMin,gammaMax);
else
thetaDeg=formCycleThetaVectorPara2fanZ(dthetaDeg);%0:359
end%thetaDeg=-68:248 for 'minimal'
numelGamma=numel(gammaDeg);Pint=zeros(numelGamma,n);%n = size(P,2);%360
t = d*sin(gammaRad); % t approximates fan beam as parallel beam.
for i = 1:numel(pthetaDeg),%szPloc=size(ploc);   1   187
    tVec=P(:,i);tVec=tVec';%sztVec=size(tVec);1, 187;   interp;  'pchip'
    Pint(:,i) = interp1(ploc,tVec,t,interp)';      
end% szPint=size(Pint)%[133, 360]
if strcmp(ParallelCoverage,'Cycle') | strcmp(ParallelCoverage,'cycle'),
    Ppad = Pint;pthetapad = pthetaDeg;
else,%ParallelCoverage,'halfcycle')
    [Ppad, pthetapad] = repPforCycleCoverage(Pint,pthetaDeg);
end

gammaRange=gammaMax-gammaMin;ptmask = (pthetapad >= 360 - gammaRange);
ptmask2=(pthetapad<=gammaRange);Ppad=[Ppad(:,ptmask) Ppad Ppad(:,ptmask2)];
pthetapad = [pthetapad(ptmask)-360 pthetapad pthetapad(ptmask2)+360];
F = shiftAndInterpRotationAngles(gammaDeg,thetaDeg,pthetapad,Ppad,interp);
if strcmp(ParallelCoverage,'Cycle') | strcmp(ParallelCoverage,'cycle'),
    Ppad2 = flipud(Ppad);pthetapad2 = pthetapad - 180;
    theta2 = mod(thetaDeg+180,360) - 180;
F2 = shiftAndInterpRotationAngles(gammaDeg,theta2,pthetapad2,Ppad2,interp);
    F = (F+F2)/2;% Average results
end
otheta = thetaDeg;ogamma = gammaDeg;ogamma = ogamma';F(isnan(F)) = 0;
