function [hexImgsSegmentd,nClasses,time,nEdges,szSegmsQs]=...
srmHex6SobelBd(HexIm,Qlevels,g,minSZ,W1,mHex,nHex,Bd)

tic%Stat. Region Merging by a hexagonal lattice, Q large many segments
W2=1-W1;nPixels=length(HexIm);
HexDeriv=zeros(3*nPixels,1);HexEdgeAB=zeros(3*nPixels,2);c=0;nEdges=0;
for jj=1:nHex,
    if jj==1,
        c=c+1;nEdges=nEdges+1;%ii==1
        HexDeriv(nEdges,1)=max(abs(HexIm(c+1,:)-HexIm(c,:)));
        HexEdgeAB(nEdges,1)=c;HexEdgeAB(nEdges,2)=c+1;
        for ii=2:(mHex-1),
            c=c+1;nEdges=nEdges+1;%sobDer means Sobel derivative
 sobDerT=-2*HexIm(c-1,:)+2*HexIm(c+1,:)-HexIm(c+mHex-1,:)+HexIm(c+mHex,:);
           derLR=abs(HexIm(c+1,:)-HexIm(c,:))+abs(HexIm(c-1,:)-HexIm(c,:));
            HexDeriv(nEdges,1)=max(abs(sobDerT)*W1/5+W2*derLR/2);
            HexEdgeAB(nEdges,1)=c;HexEdgeAB(nEdges,2)=c+1;
        end
        c=c+1;
    elseif jj==nHex,
        if mod(nHex,2)==0,
                c=c+1;nEdges=nEdges+1;%ii==1
 sobDerT=-2*HexIm(c,:)+2*HexIm(c+1,:)-HexIm(c-mHex,:)+HexIm(c-mHex+1,:);
                derLR=abs(HexIm(c+1,:)-HexIm(c,:));
                HexDeriv(nEdges,1)=max(abs(sobDerT)*W1/3+W2*derLR);
                HexEdgeAB(nEdges,1)=c;HexEdgeAB(nEdges,2)=c+1;            
            for ii=2:(mHex-2),
                c=c+1;nEdges=nEdges+1;%sobDer means Sobel derivative
  sobDerT=-2*HexIm(c-1,:)+2*HexIm(c+1,:)-HexIm(c-mHex,:)+HexIm(c-mHex+1,:);
           derLR=abs(HexIm(c+1,:)-HexIm(c,:))+abs(HexIm(c-1,:)-HexIm(c,:));
                HexDeriv(nEdges,1)=max(abs(sobDerT)*W1/5+W2*derLR/2);
                HexEdgeAB(nEdges,1)=c;HexEdgeAB(nEdges,2)=c+1;
            end
            c=c+1;
        else,%mod(nHex,2)==1,
        c=c+1;nEdges=nEdges+1;%ii==1
        HexDeriv(nEdges,1)=max(abs(HexIm(c+1,:)-HexIm(c,:)));
        HexEdgeAB(nEdges,1)=c;HexEdgeAB(nEdges,2)=c+1;            
            for ii=2:(mHex-1),
                c=c+1;nEdges=nEdges+1;%sobDer means Sobel derivative
  sobDerT=-2*HexIm(c-1,:)+2*HexIm(c+1,:)-HexIm(c-mHex,:)+HexIm(c-mHex+1,:);
           derLR=abs(HexIm(c+1,:)-HexIm(c,:))+abs(HexIm(c-1,:)-HexIm(c,:));
                HexDeriv(nEdges,1)=max(abs(sobDerT)*W1/5+W2*derLR/2);
                HexEdgeAB(nEdges,1)=c;HexEdgeAB(nEdges,2)=c+1;
            end
            c=c+1;
        end%End of mod(jj,2)==1,
    else, %1<jj<nHex,
        if mod(jj,2)==0,
            c=c+1;nEdges=nEdges+1; %ii==1
 sobDerT=-2*HexIm(c,:)+2*HexIm(c+1,:)-HexIm(c-mHex,:)+HexIm(c-mHex+1,:)...
                -HexIm(c+mHex-1,:)+HexIm(c+mHex,:);
            derLR=abs(HexIm(c+1,:)-HexIm(c,:));
            HexDeriv(nEdges,1)=max(abs(sobDerT)*W1/4+W2*derLR);
            HexEdgeAB(nEdges,1)=c;HexEdgeAB(nEdges,2)=c+1;
            for ii=2:(mHex-2),
                c=c+1;nEdges=nEdges+1;%sobDer means Sobel derivative
sobDerT=-2*HexIm(c-1,:)+2*HexIm(c+1,:)-HexIm(c-mHex,:)+HexIm(c-mHex+1,:)...
                    -HexIm(c+mHex-1,:)+HexIm(c+mHex,:);
           derLR=abs(HexIm(c+1,:)-HexIm(c,:))+abs(HexIm(c-1,:)-HexIm(c,:));
                HexDeriv(nEdges,1)=max(abs(sobDerT)*W1/6+W2*derLR/2);
                HexEdgeAB(nEdges,1)=c;HexEdgeAB(nEdges,2)=c+1;
            end
            c=c+1;
        else,%mod(jj,2)==1,
            c=c+1;nEdges=nEdges+1; %ii==1
            HexDeriv(nEdges,1)=max(abs(-HexIm(c,:)+HexIm(c+1,:)));
            HexEdgeAB(nEdges,1)=c;HexEdgeAB(nEdges,2)=c+1;
            for ii=2:(mHex-1),
                c=c+1;nEdges=nEdges+1;%sobDer means Sobel derivative
sobDerT=-2*HexIm(c-1,:)+2*HexIm(c+1,:)-HexIm(c-mHex,:)+HexIm(c-mHex+1,:)...
                    -HexIm(c+mHex-1,:)+HexIm(c+mHex,:);
           derLR=abs(HexIm(c+1,:)-HexIm(c,:))+abs(HexIm(c-1,:)-HexIm(c,:));
                HexDeriv(nEdges,1)=max(abs(sobDerT)*W1/6+W2*derLR/2);
                HexEdgeAB(nEdges,1)=c;HexEdgeAB(nEdges,2)=c+1;
            end
            c=c+1;
        end%End of mod(jj,2)==1,
    end%End of 1<jj<nHex,
end%End of jj=1:nHex,%***End of horizontal derivatives
c=0;%%***Begin derivatives of 60 degree directions
for jj=1:(nHex-1),
    if jj==1,
        c=c+1;nEdges=nEdges+1;%ii==1
        HexDeriv(nEdges,1)=max(abs(HexIm(c+mHex,:)-HexIm(c,:)));
        HexEdgeAB(nEdges,1)=c;HexEdgeAB(nEdges,2)=c+mHex;
        for ii=2:(mHex-1),
            c=c+1;nEdges=nEdges+1;%sobDer means Sobel derivative
   sobDerT=-2*HexIm(c,:)+2*HexIm(c+mHex,:)-HexIm(c-1,:)+HexIm(c+mHex-1,:);
            derLR=abs(HexIm(c+mHex,:)-HexIm(c,:));
            HexDeriv(nEdges,1)=max(abs(sobDerT)*W1/3+W2*derLR);
            HexEdgeAB(nEdges,1)=c;HexEdgeAB(nEdges,2)=c+mHex;
        end
        c=c+1;
    else, %jj>1,  if jj==(nHex-1),
        if mod(jj,2)==1,%mod(nHex,2)==0,
            c=c+1;nEdges=nEdges+1;%ii==1
    sobDerT=-2*HexIm(c,:)+2*HexIm(c+mHex,:)-HexIm(c-mHex+1,:)+HexIm(c+1,:);
            derLR=abs(HexIm(c+mHex,:)-HexIm(c,:));
            HexDeriv(nEdges,1)=max(abs(sobDerT)*W1/3+W2*derLR);
            HexEdgeAB(nEdges,1)=c;HexEdgeAB(nEdges,2)=c+mHex;
            for ii=2:(mHex-1),
                c=c+1;nEdges=nEdges+1;%sobDer means Sobel derivative
sobDerT=2*HexIm(c+mHex,:)-2*HexIm(c-mHex,:)+HexIm(c+mHex-1,:)...
-HexIm(c-1,:)+HexIm(c+1,:)-HexIm(c-mHex+1,:);
    derLR=abs(HexIm(c+mHex,:)-HexIm(c,:))+abs(HexIm(c-mHex,:)-HexIm(c,:));
                HexDeriv(nEdges,1)=max(abs(sobDerT)*W1/6+W2*derLR/2);
                HexEdgeAB(nEdges,1)=c;HexEdgeAB(nEdges,2)=c+mHex;
            end
            c=c+1;
        else,%mod(jj,2)==0,  %mod(nHex,2)==1
            c=c+1;nEdges=nEdges+1;%ii==1
sobDerT=...
    -2*HexIm(c-mHex,:)+2*HexIm(c+mHex,:)-HexIm(c-mHex+1,:)+HexIm(c+1,:);
    derLR=abs(HexIm(c+mHex,:)-HexIm(c,:))+abs(HexIm(c-mHex,:)-HexIm(c,:));
            HexDeriv(nEdges,1)=max(abs(sobDerT)*W1/5+W2*derLR/2);
            HexEdgeAB(nEdges,1)=c;HexEdgeAB(nEdges,2)=c+mHex;
            for ii=2:(mHex-2),
                c=c+1;nEdges=nEdges+1;%sobDer means Sobel derivative
sobDerT=...
    -2*HexIm(c-mHex,:)+2*HexIm(c+mHex,:)+HexIm(c+mHex-1,:)-HexIm(c-1,:)...
                    +HexIm(c+1,:)-HexIm(c-mHex+1,:);
    derLR=abs(HexIm(c+mHex,:)-HexIm(c,:))+abs(HexIm(c-mHex,:)-HexIm(c,:));
                HexDeriv(nEdges,1)=max(abs(sobDerT)*W1/6+W2*derLR/2);
                HexEdgeAB(nEdges,1)=c;HexEdgeAB(nEdges,2)=c+mHex;
            end
            c=c+1;nEdges=nEdges+1;%ii==mHex-1
sobDerT=...
    -2*HexIm(c-mHex,:)+2*HexIm(c+mHex,:)+HexIm(c+mHex-1,:)-HexIm(c-1,:);
    derLR=abs(HexIm(c+mHex,:)-HexIm(c,:))+abs(HexIm(c-mHex,:)-HexIm(c,:));
            HexDeriv(nEdges,1)=max(abs(sobDerT)*W1/5+W2*derLR/2);
            HexEdgeAB(nEdges,1)=c;HexEdgeAB(nEdges,2)=c+mHex;
        end%End of mod(jj,2)==0,  %mod(nHex,2)==1
    end%End of 1<jj<nHex,
end%End of jj=1:nHex,%***End of derivatives of 60 degree directions
c=0;%%***Begin derivatives of 120 degree directions
for jj=1:(nHex-1),
    if jj==1,
        c=c+1;
        for ii=2:(mHex-1),
            c=c+1;nEdges=nEdges+1;%sobDer means Sobel derivative
  sobDerT=-2*HexIm(c,:)+2*HexIm(c+mHex-1,:)-HexIm(c+1,:)+HexIm(c+mHex,:);
            derLR=abs(HexIm(c+mHex-1,:)-HexIm(c,:));
            HexDeriv(nEdges,1)=max(abs(sobDerT)*W1/3+W2*derLR);
            HexEdgeAB(nEdges,1)=c;HexEdgeAB(nEdges,2)=c+mHex-1;
        end
            c=c+1;nEdges=nEdges+1;%ii==mHex
 sobDerT=-2*HexIm(c,:)+2*HexIm(c+mHex-1,:)-HexIm(c-1,:)+HexIm(c+mHex-2,:);
            derLR=abs(HexIm(c+mHex-1,:)-HexIm(c,:));
            HexDeriv(nEdges,1)=max(abs(sobDerT)*W1/3+W2*derLR);
            HexEdgeAB(nEdges,1)=c;HexEdgeAB(nEdges,2)=c+mHex-1;        
    else, %jj>1,  if jj==(nHex-1),
        if mod(jj,2)==1,%mod(nHex,2)==0,
            c=c+1;
            for ii=2:(mHex-1),
                c=c+1;nEdges=nEdges+1;%sobDer means Sobel derivative
sobDerT=2*HexIm(c+mHex-1,:)-2*HexIm(c-mHex+1,:)-HexIm(c-mHex,:)...
    +HexIm(c-1,:)-HexIm(c+1,:)+HexIm(c+mHex,:);
derLR=abs(HexIm(c+mHex-1,:)-HexIm(c,:))+abs(HexIm(c-mHex+1,:)-HexIm(c,:));
                HexDeriv(nEdges,1)=max(abs(sobDerT)*W1/6+W2*derLR/2);
                HexEdgeAB(nEdges,1)=c;HexEdgeAB(nEdges,2)=c+mHex-1;
            end
                c=c+1;nEdges=nEdges+1;%ii==mHex
    sobDerT=2*HexIm(c+mHex-1,:)-2*HexIm(c,:)-HexIm(c-mHex,:)+HexIm(c-1,:);
                derLR=abs(HexIm(c+mHex-1,:)-HexIm(c,:));
                HexDeriv(nEdges,1)=max(abs(sobDerT)*W1/3+W2*derLR);
                HexEdgeAB(nEdges,1)=c;HexEdgeAB(nEdges,2)=c+mHex-1;            
        else,%mod(jj,2)==0,  %mod(nHex,2)==1
            c=c+1;nEdges=nEdges+1;%ii==1
sobDerT=...
    -2*HexIm(c-mHex+1,:)+2*HexIm(c+mHex-1,:)+HexIm(c+mHex,:)-HexIm(c+1,:);
derLR=abs(HexIm(c+mHex-1,:)-HexIm(c,:))+abs(HexIm(c-mHex+1,:)-HexIm(c,:));
            HexDeriv(nEdges,1)=max(abs(sobDerT)*W1/5+W2*derLR/2);
            HexEdgeAB(nEdges,1)=c;HexEdgeAB(nEdges,2)=c+mHex-1;
            for ii=2:(mHex-2),
                c=c+1;nEdges=nEdges+1;%sobDer means Sobel derivative
sobDerT=-2*HexIm(c-mHex+1,:)+2*HexIm(c+mHex-1,:)+HexIm(c+mHex,:)...
    -HexIm(c+1,:)+HexIm(c-1,:)-HexIm(c-mHex,:);
derLR=abs(HexIm(c+mHex-1,:)-HexIm(c,:))+abs(HexIm(c-mHex+1,:)-HexIm(c,:));
                HexDeriv(nEdges,1)=max(abs(sobDerT)*W1/6+W2*derLR/2);
                HexEdgeAB(nEdges,1)=c;HexEdgeAB(nEdges,2)=c+mHex-1;
            end
            c=c+1;nEdges=nEdges+1;%ii==mHex-1
sobDerT=...
    -2*HexIm(c-mHex+1,:)+2*HexIm(c+mHex-1,:)-HexIm(c-mHex,:)+HexIm(c-1,:);
derLR=abs(HexIm(c+mHex-1,:)-HexIm(c,:))+abs(HexIm(c-mHex+1,:)-HexIm(c,:));
            HexDeriv(nEdges,1)=max(abs(sobDerT)*W1/5+W2*derLR/2);
            HexEdgeAB(nEdges,1)=c;HexEdgeAB(nEdges,2)=c+mHex-1;
        end%End of mod(jj,2)==0,  %mod(nHex,2)==1
    end%End of 1<jj<nHex,
end%End of jj=1:nHex,%***End of derivatives of 120 degree directions
HexDeriv=HexDeriv(1:nEdges);HexEdgeAB=HexEdgeAB(1:nEdges,:);
[~,index]=sort(HexDeriv);nQ=numel(Qlevels);nPixels=length(HexIm);
hexImgsSegmentd=cell(nQ,1);A=[1:nPixels]';treerank=zeros(nPixels,1);
szSegms=ones(nPixels,1);imSeg1=HexIm(:,1);imSeg2=HexIm(:,2);
imSeg3=HexIm(:,3);nClasses=zeros(1,nQ);
logdelta=2*log(6*nPixels);imFinalHex=zeros(nPixels,1);nCl=nPixels;
for Q=Qlevels
    iter=find(Q==Qlevels);
    for i=1:nEdges
        C1=HexEdgeAB(index(i),1);C2=HexEdgeAB(index(i),2);
        while (A(C1)~=C1 ); C1=A(C1); end
        while (A(C2)~=C2 ); C2=A(C2); end
        % Compute the predicate, region merging test
        dR=(imSeg1(C1)-imSeg1(C2))^2;
        dG=(imSeg2(C1)-imSeg2(C2))^2;dB=(imSeg3(C1)-imSeg3(C2))^2;        
        dev=g^2*logdelta*(1/szSegms(C1)+1/szSegms(C2))/(2*Q);                
        predicat=( (dR<dev) & (dG<dev) & (dB<dev) );               
   if (((C1~=C2)&predicat&(nCl>Bd))|szSegms(C1)<=minSZ|szSegms(C2)<=minSZ)
            if treerank(C1)>treerank(C2)%Find the new root for both regions
                A(C2) = C1; reg=C1;regNot=C2;
            elseif treerank(C1) < treerank(C2)
                A(C1) = C2; reg=C2;regNot=C1;
            elseif C1 ~= C2
                A(C2) = C1; reg=C1;regNot=C2;
                treerank(C1) = treerank(C1) + 1;
            end
            if C1~=C2% Merge regions
                nreg=szSegms(C1)+szSegms(C2);nCl=nCl-1;
            imSeg1(reg)=(szSegms(C1)*imSeg1(C1)+szSegms(C2)*imSeg1(C2))/nreg;
            imSeg2(reg)=(szSegms(C1)*imSeg2(C1)+szSegms(C2)*imSeg2(C2))/nreg;
            imSeg3(reg)=(szSegms(C1)*imSeg3(C1)+szSegms(C2)*imSeg3(C2))/nreg;
            szSegms(reg)=nreg;nClasses(1,iter)=nClasses(1,iter)+1;
            szSegms(regNot)=0;
            end
        end
    end    
    while 1
        map_ = A(A) ;
        if isequal(map_,A) ; break ; end
        A = map_ ;
    end
imFinalHex(:,1)=imSeg1(A);imFinalHex(:,2)=imSeg2(A);
imFinalHex(:,3)=imSeg3(A);hexImgsSegmentd{iter}=imFinalHex;%maps{iter}=A;
szSegmsOutput=szSegms(:);szSegmsOutput=nonzeros(szSegmsOutput);
szSegmsQs{iter}=szSegmsOutput';
end%end for Q=Qlevels
for t=iter:-1:1,%t=iter:-1:2,
    tSum=0;
    for j=1:t,
    tSum=tSum+nClasses(1,j);
    end
    nClasses(1,t)=tSum;
end
nClasses=nPixels-nClasses;
time=toc;%End of the function srmHex;  nPixelsAndEdgesHex=[nPixels,nEdges];