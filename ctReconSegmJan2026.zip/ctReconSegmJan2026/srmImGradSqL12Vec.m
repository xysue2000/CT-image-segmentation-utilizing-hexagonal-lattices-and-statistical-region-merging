function [SqL12Deriv,SqL12EdgeAB,edgek]=srmImGradSqL12Vec(I,W1)%8-connectivity

tic%srmImGrad8N2Vec
W2=1-W1;m=size(I,1);n=size(I,2);c=size(I,3);mMinus1=m-1;nMinus1=n-1;
SqL12Deriv=zeros(6*m*n,1);I1=I(:,:,1);I2=I(:,:,2);I3=I(:,:,3);
Ivec1=I1(:);Ivec2=I2(:);Ivec3=I3(:);Ivec=zeros(length(Ivec1),3);
Ivec(:,1)=Ivec1;Ivec(:,2)=Ivec2;Ivec(:,3)=Ivec3;
SqL12EdgeAB=zeros(6*m*n,2);%Each row has two numbers representing an edge 
c=0;%c denotes the pixel ordered by columns of the matrix
edgek=0;%edgek denotes edge ordered according to the the following code

%Downward edges
for i=1:1,
    for j=1:n,
        edgek=edgek+1;a=(j-1)*m+i;b=(j-1)*m+i+1;%Downward edges
        SqL12EdgeAB(edgek,:)=[a,b];
%         DerivativeR=I(i+1,j,:)-I(i,j,:);
DerivativeR=Ivec(b,:)-Ivec(a,:);
        SqL12Deriv(edgek,1)=max(abs(DerivativeR));
    end
end
for i=2:mMinus1,
    for j=[1,n],
        edgek=edgek+1;a=(j-1)*m+i;b=(j-1)*m+i+1;%Downward edges
        SqL12EdgeAB(edgek,:)=[a,b];
%         DerivativeR=I(i+1,j,:)-I(i,j,:);
DerivativeR=Ivec(b,:)-Ivec(a,:);
        SqL12Deriv(edgek,1)=max(abs(DerivativeR));
    end
end
for i=2:mMinus1,
    for j=2:nMinus1,
        edgek=edgek+1;a=(j-1)*m+i;b=(j-1)*m+i+1;%Downward edges
        SqL12EdgeAB(edgek,:)=[a,b];
DerivativeR=Ivec(b,:)-Ivec(a,:);
%   IxSobel=(2*I(i+1,j,:)-2*I(i-1,j,:)+I(i+1,j+1,:)-I(i-1,j+1,:)+...
%                 +I(i+1,j-1,:)-I(i-1,j-1,:))/8;
  IxSobel=(2*Ivec(b,:)-2*Ivec((j-1)*m+i-1,:)+Ivec(j*m+i+1,:)-Ivec(j*m+i-1,:)+...
                +Ivec((j-2)*m+i+1,:)-Ivec((j-2)*m+i-1,:))/8;
            SqL12Deriv(edgek,1)=max(W1*abs(IxSobel)+W2*abs(DerivativeR));
    end
end

%Edges towards the right side
for i=1:m,
    for j=1:1,
        edgek=edgek+1;a=(j-1)*m+i;b=j*m+i;%Edges towards the right side
                SqL12EdgeAB(edgek,:)=[a,b];
DerivativeU=Ivec(b,:)-Ivec(a,:);
        SqL12Deriv(edgek,1)=max(abs(DerivativeU));
    end
end
for i=1:1,
    for j=2:nMinus1,
        edgek=edgek+1;%Edges towards the right side
        a=(j-1)*m+i;b=j*m+i;
        SqL12EdgeAB(edgek,:)=[a,b];
DerivativeU=Ivec(b,:)-Ivec(a,:);
        SqL12Deriv(edgek,1)=max(abs(DerivativeU));
    end
end
for i=m:m,
    for j=2:nMinus1,
        edgek=edgek+1;%Edges towards the right side
                a=(j-1)*m+i;b=j*m+i;
        SqL12EdgeAB(edgek,:)=[a,b];
DerivativeU=Ivec(b,:)-Ivec(a,:);
        SqL12Deriv(edgek,1)=max(abs(DerivativeU));
    end
end
for i=2:mMinus1,
    for j=2:nMinus1,
        edgek=edgek+1;a=(j-1)*m+i;b=j*m+i;%Edges towards the right side
        SqL12EdgeAB(edgek,:)=[a,b];
        DerivativeU=Ivec(b,:)-Ivec(a,:);
 IySobel=(2*Ivec(j*m+i,:)-2*Ivec((j-2)*m+i,:)+Ivec(j*m+i+1,:)-Ivec((j-2)*m+i+1,:)+...
                +Ivec(j*m+i-1,:)-Ivec((j-2)*m+i-1,:))/8;
            SqL12Deriv(edgek,1)=max(W1*abs(IySobel)+W2*abs(DerivativeU));
    end
end

%Derivative of downward 45 degree direction
for i=1:1,
    for j=1:nMinus1,
        edgek=edgek+1;a=(j-1)*m+i;b=j*m+i+1;
        SqL12EdgeAB(edgek,:)=[a,b];%Edges of downward 45 degree direction
        Derivative45U=Ivec(b,:)-Ivec(a,:);%Der of up right di.
        SqL12Deriv(edgek,1)=max(abs(Derivative45U))/sqrt(2);
    end
end
for i=2:mMinus1,
    for j=1:1,
        edgek=edgek+1;a=(j-1)*m+i;b=j*m+i+1;
        SqL12EdgeAB(edgek,:)=[a,b];%Edges of downward 45 degree direction
        Derivative45U=Ivec(b,:)-Ivec(a,:);%Der of up right di.
        SqL12Deriv(edgek,1)=max(abs(Derivative45U))/sqrt(2);
    end
end
for i=2:mMinus1,
    for j=2:nMinus1,
        edgek=edgek+1;a=(j-1)*m+i;b=j*m+i+1;
        SqL12EdgeAB(edgek,:)=[a,b];%Edges of downward 45 degree direction
        Derivative45U=Ivec(b,:)-Ivec(a,:);%Der of up right di.
            Sobel45=(2*(Ivec(b,:)-Ivec((j-2)*m+i-1,:))+Ivec(j*m+i,:)...
                -Ivec((j-1)*m+i-1,:)+Ivec((j-1)*m+i+1,:)-Ivec((j-2)*m+i,:))/6;
      SqL12Deriv(edgek,1)=max(W1*abs(Sobel45)+W2*abs(Derivative45U))/sqrt(2);
    end
end

%Edges of upward 45 degree direction
for i=m:m,
    for j=1:(n-1),
        edgek=edgek+1;a=(j-1)*m+i;b=j*m+i-1;
        SqL12EdgeAB(edgek,:)=[a,b];%Edges of upward 45 degree direction
       Derivative135U=Ivec(b,:)-Ivec(a,:);%Der of up right di.
           SqL12Deriv(edgek,1)=max(abs(Derivative135U))/sqrt(2);
    end
end
for i=2:mMinus1,
    for j=1:1,
        edgek=edgek+1;a=(j-1)*m+i;b=j*m+i-1;
        SqL12EdgeAB(edgek,:)=[a,b];%Edges of upward 45 degree direction
       Derivative135U=Ivec(b,:)-Ivec(a,:);%Der of up right di.
           SqL12Deriv(edgek,1)=max(abs(Derivative135U))/sqrt(2);
    end
end
for i=2:mMinus1,
    for j=2:(n-1),
        edgek=edgek+1;a=(j-1)*m+i;b=j*m+i-1;
        SqL12EdgeAB(edgek,:)=[a,b];%Edges of upward 45 degree direction
       Derivative135U=Ivec(b,:)-Ivec(a,:);%Der of up right di.
       Sobel135=(2*(Ivec(b,:)-Ivec((j-2)*m+i+1,:))+Ivec(j*m+i,:)...
           -Ivec((j-1)*m+i+1,:)+Ivec((j-1)*m+i-1,:)-Ivec((j-2)*m+i,:))/6;
SqL12Deriv(edgek,1)=max(W1*abs(Sobel135)+W2*abs(Derivative135U))/sqrt(2);
    end
end

%%%%%%%%%%%%%%%%%%%%% Edges with length 2 %%%%%%%%%%%%%%%%%%%%%%%%%%%
mMinus2=mMinus1-1;nMinus2=nMinus1-1;
%Downward edges with length 2
for i=1:1,
    for j=1:n,
        edgek=edgek+1;a=(j-1)*m+i;b=(j-1)*m+i+2;%Downward edges, length 2
        SqL12EdgeAB(edgek,:)=[a,b];
%         DerivativeR=I(i+1,j,:)-I(i,j,:);
DerivativeR=Ivec(b,:)-Ivec(a,:);
        SqL12Deriv(edgek,1)=max(abs(DerivativeR))/2;
    end
end
for i=2:mMinus2,
    for j=[1,n],
        edgek=edgek+1;a=(j-1)*m+i;b=(j-1)*m+i+2;%Downward edges, length 2
        SqL12EdgeAB(edgek,:)=[a,b];
%         DerivativeR=I(i+1,j,:)-I(i,j,:);
DerivativeR=Ivec(b,:)-Ivec(a,:);
        SqL12Deriv(edgek,1)=max(abs(DerivativeR))/2;
    end
end
for i=2:mMinus2,
    for j=2:nMinus1,
        edgek=edgek+1;a=(j-1)*m+i;b=(j-1)*m+i+2;%Downward edges, length 2
        SqL12EdgeAB(edgek,:)=[a,b];
DerivativeR=(Ivec(b,:)-Ivec(a,:))/2;
%   IxSobel=(2*I(i+1,j,:)-2*I(i-1,j,:)+I(i+1,j+1,:)-I(i-1,j+1,:)+...
%                 +I(i+1,j-1,:)-I(i-1,j-1,:))/8;
  IxSobel=(2*Ivec(b,:)-2*Ivec((j-1)*m+i,:)+Ivec(j*m+i+2,:)-Ivec(j*m+i,:)+...
                +Ivec((j-2)*m+i+2,:)-Ivec((j-2)*m+i,:))/8;
            SqL12Deriv(edgek,1)=max(W1*abs(IxSobel)+W2*abs(DerivativeR));
    end
end

%Edges towards the right side with length 2
for i=1:m,
    for j=1:1,
        edgek=edgek+1;a=(j-1)*m+i;b=(j+1)*m+i;%Edges towards the right side
                SqL12EdgeAB(edgek,:)=[a,b];
DerivativeU=Ivec(b,:)-Ivec(a,:);
        SqL12Deriv(edgek,1)=max(abs(DerivativeU))/2;
    end
end
for i=1:1,
    for j=2:nMinus2,
        edgek=edgek+1;%Edges towards the right side, length 2
        a=(j-1)*m+i;b=(j+1)*m+i;
        SqL12EdgeAB(edgek,:)=[a,b];
DerivativeU=Ivec(b,:)-Ivec(a,:);
        SqL12Deriv(edgek,1)=max(abs(DerivativeU))/2;
    end
end
for i=m:m,
    for j=2:nMinus2,
        edgek=edgek+1;%Edges towards the right side, length 2
                a=(j-1)*m+i;b=(j+1)*m+i;
        SqL12EdgeAB(edgek,:)=[a,b];
DerivativeU=Ivec(b,:)-Ivec(a,:);
        SqL12Deriv(edgek,1)=max(abs(DerivativeU))/2;
    end
end
for i=2:mMinus1,
    for j=2:nMinus2,
        edgek=edgek+1;a=(j-1)*m+i;b=(j+1)*m+i;%Edges towards the right side
        SqL12EdgeAB(edgek,:)=[a,b];
        DerivativeU=(Ivec(b,:)-Ivec(a,:))/2;
 IySobel=(2*Ivec((j+1)*m+i,:)-2*Ivec((j-1)*m+i,:)+Ivec((j+1)*m+i+1,:)-Ivec((j-1)*m+i+1,:)+...
                +Ivec((j+1)*m+i-1,:)-Ivec((j-1)*m+i-1,:))/8;
            SqL12Deriv(edgek,1)=max(W1*abs(IySobel)+W2*abs(DerivativeU));
    end
end
SqL12Deriv=SqL12Deriv(1:edgek,:);SqL12EdgeAB=SqL12EdgeAB(1:edgek,:);
SqL12srmImGrad8NtimeNNNNNNNNNNN=toc