
This repository contains MATLAB codes to perform the following actions.
1).  CT image reconstruction on square and hexagonal lattices using Fan-beam Filtered back-projection. 
2).  segmentation on the reconstructed images using statistical region merging for square lattices with connectivity 4, 8, and 12 and for hexagonal lattices with connectivity 12. The code image segmentation using FastFCMeans is also included.

Just need to run drFanbeamReconSegm for CT image reconstruction on hexagonal lattices using Fan-beam Filtered back-projection and then segment the reconstructed images using statistical region merging. 



Copyright (c) 2025, Xiqiang Zheng

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

