function theta=...
    formMinimalThetaVectorPara2fanZ(n,dthetaDeg,gammaMin,gammaMax);

ne = n*180*eps;
theta=formVectorCenteredOnZero(dthetaDeg,-gammaMax+ne,180-gammaMin-ne);
theta = [min(theta)-dthetaDeg theta max(theta)+dthetaDeg];