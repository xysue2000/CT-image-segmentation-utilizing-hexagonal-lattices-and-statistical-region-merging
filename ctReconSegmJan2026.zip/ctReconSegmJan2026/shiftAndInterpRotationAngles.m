function F=shiftAndInterpRotationAngles(gamma,theta,pthetapad,Ppad,interp)
numelGamma=numel(gamma); F=zeros(numelGamma,numel(theta));
for ii=1:numelGamma,%shift to correct for fanbeam angle offsets & interp.
    F(ii,:)=interp1(pthetapad+gamma(ii),Ppad(ii,:),theta,interp);
end