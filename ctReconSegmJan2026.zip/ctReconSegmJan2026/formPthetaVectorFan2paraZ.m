function ptheta = formPthetaVectorFan2paraZ(dptheta, parallelCoverage)
if strcmp(parallelCoverage,'Cycle') | strcmp(parallelCoverage,'cycle')
    ptheta = 0:dptheta:(360-dptheta);    
else
    ptheta = 0:dptheta:(180-dptheta);    
end 