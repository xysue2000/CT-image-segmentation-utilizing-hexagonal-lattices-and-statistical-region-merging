% License: MIT © 2019 Anton Semechko a.semechko@gmail.com
% Anton Semechko. Fast fuzzy c-means image segmentation 
% https://github.com/AntonSemechko/Fast-Fuzzy-C-Means-Segmentation
% https://www.mathworks.com/matlabcentral/fileexchange/41967-fast-fuzzy-c-means-image-segmentation
function [C,U,LUT,H]=FastFCMeans(im,c)

q=2;Imin=double(min(im(:)));Imax=double(max(im(:)));I=(Imin:Imax)';
dI=(Imax-Imin)/c;C=Imin+dI/2:dI:Imax;H=hist(double(im(:)),I);H=H(:);dC=Inf;
while dC>1E-3,
    C0=C;D=abs(bsxfun(@minus,I,C));D=D.^(2/(q-1))+eps;
    U=bsxfun(@times,D,sum(1./D,2));U=1./(U+eps);
    UH=bsxfun(@times,U.^q,H);C=sum(bsxfun(@times,UH,I),1)./sum(UH,1);
    C=sort(C,'ascend');dC=max(abs(C-C0));
end
[~,LUT]=max(U,[],2);