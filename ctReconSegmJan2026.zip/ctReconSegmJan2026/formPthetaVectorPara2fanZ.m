function [ptheta,dpthetaDeg] = formPthetaVectorPara2fanZ(n,ParallelCoverage)
if strcmp(ParallelCoverage,'Cycle') | strcmp(ParallelCoverage,'cycle'),
    dpthetaDeg = 360/n;
else 
    dpthetaDeg = 180/n;
end
ptheta = dpthetaDeg * (0:n-1);    
