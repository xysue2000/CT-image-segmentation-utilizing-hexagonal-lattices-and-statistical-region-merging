function [HexDeriv,HexEdgeAB,edgek]=...
    Hex12Derivatives0(HexIm,W1,mHex,nHex,HexIJ2C,B1,B2)
tic
W2=1-W1;nPixels=length(HexIm);
HexDeriv=zeros(6*nPixels,1);HexEdgeAB=zeros(6*nPixels,2);
c=0;%c denotes the pixel ordered from left to right and from bottom up
edgek=0;%edgek denotes edge ordered according to the the following code
for jj=1:nHex,
    if jj==1,
        edgek=edgek+1;c=c+1;%ii==1
        HexDeriv(edgek,1)=max(abs(HexIm(c+1,:)-HexIm(c,:)));
        HexEdgeAB(edgek,1)=c;HexEdgeAB(edgek,2)=c+1;
        for ii=2:(mHex-1),
            edgek=edgek+1;c=c+1;%sobDer means Sobel derivative
 sobDerT=-2*HexIm(c-1,:)+2*HexIm(c+1,:)-HexIm(c+mHex-1,:)+HexIm(c+mHex,:);
           derLR=abs(HexIm(c+1,:)-HexIm(c,:));
            HexDeriv(edgek,1)=max(abs(sobDerT)*W1/5+W2*derLR);
            HexEdgeAB(edgek,1)=c;HexEdgeAB(edgek,2)=c+1;
        end
        c=c+1;
    elseif jj==nHex,
        if mod(nHex,2)==0,
                c=c+1;edgek=edgek+1;%ii==1
 sobDerT=-2*HexIm(c,:)+2*HexIm(c+1,:)-HexIm(c-mHex,:)+HexIm(c-mHex+1,:);
                derLR=abs(HexIm(c+1,:)-HexIm(c,:));
                HexDeriv(edgek,1)=max(abs(sobDerT)*W1/3+W2*derLR);
                HexEdgeAB(edgek,1)=c;HexEdgeAB(edgek,2)=c+1;            
            for ii=2:(mHex-2),
                c=c+1;edgek=edgek+1;%sobDer means Sobel derivative
  sobDerT=-2*HexIm(c-1,:)+2*HexIm(c+1,:)-HexIm(c-mHex,:)+HexIm(c-mHex+1,:);
           derLR=abs(HexIm(c+1,:)-HexIm(c,:));
                HexDeriv(edgek,1)=max(abs(sobDerT)*W1/5+W2*derLR);
                HexEdgeAB(edgek,1)=c;HexEdgeAB(edgek,2)=c+1;
            end
            c=c+1;
        else,%mod(nHex,2)==1,
        c=c+1;edgek=edgek+1;%ii==1
        HexDeriv(edgek,1)=max(abs(HexIm(c+1,:)-HexIm(c,:)));
        HexEdgeAB(edgek,1)=c;HexEdgeAB(edgek,2)=c+1;            
            for ii=2:(mHex-1),
                c=c+1;edgek=edgek+1;%sobDer means Sobel derivative
  sobDerT=-2*HexIm(c-1,:)+2*HexIm(c+1,:)-HexIm(c-mHex,:)+HexIm(c-mHex+1,:);
           derLR=abs(HexIm(c+1,:)-HexIm(c,:));
                HexDeriv(edgek,1)=max(abs(sobDerT)*W1/5+W2*derLR);
                HexEdgeAB(edgek,1)=c;HexEdgeAB(edgek,2)=c+1;
            end
            c=c+1;
        end%End of mod(jj,2)==1,
    else, %1<jj<nHex,
        if mod(jj,2)==0,
            c=c+1;edgek=edgek+1; %ii==1
 sobDerT=-2*HexIm(c,:)+2*HexIm(c+1,:)-HexIm(c-mHex,:)+HexIm(c-mHex+1,:)...
                -HexIm(c+mHex-1,:)+HexIm(c+mHex,:);
            derLR=abs(HexIm(c+1,:)-HexIm(c,:));
            HexDeriv(edgek,1)=max(abs(sobDerT)*W1/4+W2*derLR);
            HexEdgeAB(edgek,1)=c;HexEdgeAB(edgek,2)=c+1;
            for ii=2:(mHex-2),
                c=c+1;edgek=edgek+1;%sobDer means Sobel derivative
sobDerT=-2*HexIm(c-1,:)+2*HexIm(c+1,:)-HexIm(c-mHex,:)+HexIm(c-mHex+1,:)...
                    -HexIm(c+mHex-1,:)+HexIm(c+mHex,:);
           derLR=abs(HexIm(c+1,:)-HexIm(c,:));
                HexDeriv(edgek,1)=max(abs(sobDerT)*W1/6+W2*derLR);
                HexEdgeAB(edgek,1)=c;HexEdgeAB(edgek,2)=c+1;
            end
            c=c+1;
        else,%mod(jj,2)==1,
            c=c+1;edgek=edgek+1; %ii==1
            HexDeriv(edgek,1)=max(abs(-HexIm(c,:)+HexIm(c+1,:)));
            HexEdgeAB(edgek,1)=c;HexEdgeAB(edgek,2)=c+1;
            for ii=2:(mHex-1),
                c=c+1;edgek=edgek+1;%sobDer means Sobel derivative
sobDerT=-2*HexIm(c-1,:)+2*HexIm(c+1,:)-HexIm(c-mHex,:)+HexIm(c-mHex+1,:)...
                    -HexIm(c+mHex-1,:)+HexIm(c+mHex,:);
           derLR=abs(HexIm(c+1,:)-HexIm(c,:));
                HexDeriv(edgek,1)=max(abs(sobDerT)*W1/6+W2*derLR);
                HexEdgeAB(edgek,1)=c;HexEdgeAB(edgek,2)=c+1;
            end
            c=c+1;
        end%End of mod(jj,2)==1,
    end%End of 1<jj<nHex,
end%End of jj=1:nHex,%***End of horizontal derivatives
c=0;%%***Begin derivatives of 60 degree directions
for jj=1:(nHex-1),
    if jj==1,
        c=c+1;edgek=edgek+1;%ii==1
        HexDeriv(edgek,1)=max(abs(HexIm(c+mHex,:)-HexIm(c,:)));
        HexEdgeAB(edgek,1)=c;HexEdgeAB(edgek,2)=c+mHex;
        for ii=2:(mHex-1),
            c=c+1;edgek=edgek+1;%sobDer means Sobel derivative
   sobDerT=-2*HexIm(c,:)+2*HexIm(c+mHex,:)-HexIm(c-1,:)+HexIm(c+mHex-1,:);
            derLR=abs(HexIm(c+mHex,:)-HexIm(c,:));
            HexDeriv(edgek,1)=max(abs(sobDerT)*W1/3+W2*derLR);
            HexEdgeAB(edgek,1)=c;HexEdgeAB(edgek,2)=c+mHex;
        end
        c=c+1;
    else, %jj>1,  if jj==(nHex-1),
        if mod(jj,2)==1,%mod(nHex,2)==0,
            c=c+1;edgek=edgek+1;%ii==1
    sobDerT=-2*HexIm(c,:)+2*HexIm(c+mHex,:)-HexIm(c-mHex+1,:)+HexIm(c+1,:);
            derLR=abs(HexIm(c+mHex,:)-HexIm(c,:));
            HexDeriv(edgek,1)=max(abs(sobDerT)*W1/3+W2*derLR);
            HexEdgeAB(edgek,1)=c;HexEdgeAB(edgek,2)=c+mHex;
            for ii=2:(mHex-1),
                c=c+1;edgek=edgek+1;%sobDer means Sobel derivative
sobDerT=2*HexIm(c+mHex,:)-2*HexIm(c-mHex,:)+HexIm(c+mHex-1,:)...
-HexIm(c-1,:)+HexIm(c+1,:)-HexIm(c-mHex+1,:);
    derLR=abs(HexIm(c+mHex,:)-HexIm(c,:));
                HexDeriv(edgek,1)=max(abs(sobDerT)*W1/6+W2*derLR);
                HexEdgeAB(edgek,1)=c;HexEdgeAB(edgek,2)=c+mHex;
            end
            c=c+1;
        else,%mod(jj,2)==0,  %mod(nHex,2)==1
            c=c+1;edgek=edgek+1;%ii==1
sobDerT=...
    -2*HexIm(c-mHex,:)+2*HexIm(c+mHex,:)-HexIm(c-mHex+1,:)+HexIm(c+1,:);
    derLR=abs(HexIm(c+mHex,:)-HexIm(c,:));
            HexDeriv(edgek,1)=max(abs(sobDerT)*W1/5+W2*derLR);
            HexEdgeAB(edgek,1)=c;HexEdgeAB(edgek,2)=c+mHex;
            for ii=2:(mHex-2),
                c=c+1;edgek=edgek+1;%sobDer means Sobel derivative
sobDerT=...
    -2*HexIm(c-mHex,:)+2*HexIm(c+mHex,:)+HexIm(c+mHex-1,:)-HexIm(c-1,:)...
                    +HexIm(c+1,:)-HexIm(c-mHex+1,:);
    derLR=abs(HexIm(c+mHex,:)-HexIm(c,:));
                HexDeriv(edgek,1)=max(abs(sobDerT)*W1/6+W2*derLR);
                HexEdgeAB(edgek,1)=c;HexEdgeAB(edgek,2)=c+mHex;
            end
            c=c+1;edgek=edgek+1;%ii==mHex-1
sobDerT=...
    -2*HexIm(c-mHex,:)+2*HexIm(c+mHex,:)+HexIm(c+mHex-1,:)-HexIm(c-1,:);
    derLR=abs(HexIm(c+mHex,:)-HexIm(c,:));
            HexDeriv(edgek,1)=max(abs(sobDerT)*W1/5+W2*derLR);
            HexEdgeAB(edgek,1)=c;HexEdgeAB(edgek,2)=c+mHex;
        end%End of mod(jj,2)==0,  %mod(nHex,2)==1
    end%End of 1<jj<nHex,
end%End of jj=1:nHex,%***End of derivatives of 60 degree directions
c=0;%%***Begin derivatives of 120 degree directions
for jj=1:(nHex-1),
    if jj==1,
        c=c+1;
        for ii=2:(mHex-1),
            c=c+1;edgek=edgek+1;%sobDer means Sobel derivative
  sobDerT=-2*HexIm(c,:)+2*HexIm(c+mHex-1,:)-HexIm(c+1,:)+HexIm(c+mHex,:);
            derLR=abs(HexIm(c+mHex-1,:)-HexIm(c,:));
            HexDeriv(edgek,1)=max(abs(sobDerT)*W1/3+W2*derLR);
            HexEdgeAB(edgek,1)=c;HexEdgeAB(edgek,2)=c+mHex-1;
        end
            c=c+1;edgek=edgek+1;%ii==mHex
 sobDerT=-2*HexIm(c,:)+2*HexIm(c+mHex-1,:)-HexIm(c-1,:)+HexIm(c+mHex-2,:);
            derLR=abs(HexIm(c+mHex-1,:)-HexIm(c,:));
            HexDeriv(edgek,1)=max(abs(sobDerT)*W1/3+W2*derLR);
            HexEdgeAB(edgek,1)=c;HexEdgeAB(edgek,2)=c+mHex-1;        
    else, %jj>1,  if jj==(nHex-1),
        if mod(jj,2)==1,%mod(nHex,2)==0,
            c=c+1;
            for ii=2:(mHex-1),
                c=c+1;edgek=edgek+1;%sobDer means Sobel derivative
sobDerT=2*HexIm(c+mHex-1,:)-2*HexIm(c-mHex+1,:)-HexIm(c-mHex,:)...
    +HexIm(c-1,:)-HexIm(c+1,:)+HexIm(c+mHex,:);
derLR=abs(HexIm(c+mHex-1,:)-HexIm(c,:));
                HexDeriv(edgek,1)=max(abs(sobDerT)*W1/6+W2*derLR);
                HexEdgeAB(edgek,1)=c;HexEdgeAB(edgek,2)=c+mHex-1;
            end
                c=c+1;edgek=edgek+1;%ii==mHex
    sobDerT=2*HexIm(c+mHex-1,:)-2*HexIm(c,:)-HexIm(c-mHex,:)+HexIm(c-1,:);
                derLR=abs(HexIm(c+mHex-1,:)-HexIm(c,:));
                HexDeriv(edgek,1)=max(abs(sobDerT)*W1/3+W2*derLR);
                HexEdgeAB(edgek,1)=c;HexEdgeAB(edgek,2)=c+mHex-1;            
        else,%mod(jj,2)==0,  %mod(nHex,2)==1
            c=c+1;edgek=edgek+1;%ii==1
sobDerT=...
    -2*HexIm(c-mHex+1,:)+2*HexIm(c+mHex-1,:)+HexIm(c+mHex,:)-HexIm(c+1,:);
derLR=abs(HexIm(c+mHex-1,:)-HexIm(c,:));
            HexDeriv(edgek,1)=max(abs(sobDerT)*W1/5+W2*derLR);
            HexEdgeAB(edgek,1)=c;HexEdgeAB(edgek,2)=c+mHex-1;
            for ii=2:(mHex-2),
                c=c+1;edgek=edgek+1;%sobDer means Sobel derivative
sobDerT=-2*HexIm(c-mHex+1,:)+2*HexIm(c+mHex-1,:)+HexIm(c+mHex,:)...
    -HexIm(c+1,:)+HexIm(c-1,:)-HexIm(c-mHex,:);
derLR=abs(HexIm(c+mHex-1,:)-HexIm(c,:));
                HexDeriv(edgek,1)=max(abs(sobDerT)*W1/6+W2*derLR);
                HexEdgeAB(edgek,1)=c;HexEdgeAB(edgek,2)=c+mHex-1;
            end
            c=c+1;edgek=edgek+1;%ii==mHex-1
sobDerT=...
    -2*HexIm(c-mHex+1,:)+2*HexIm(c+mHex-1,:)-HexIm(c-mHex,:)+HexIm(c-1,:);
derLR=abs(HexIm(c+mHex-1,:)-HexIm(c,:));
            HexDeriv(edgek,1)=max(abs(sobDerT)*W1/5+W2*derLR);
            HexEdgeAB(edgek,1)=c;HexEdgeAB(edgek,2)=c+mHex-1;
        end%End of mod(jj,2)==0,  %mod(nHex,2)==1
    end%End of 1<jj<nHex,
end%End of jj=1:nHex,%***End of derivatives of 120 degree directions

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
hexScale=sqrt(3);
for jj=1:nHex,
    shiftNum=floor(jj/2);
    if mod(jj,2)==1,
        for ii=(1+shiftNum):(mHex+shiftNum),
            point=ii*B1+jj*B2;x=point(1,1);y=point(1,2);
            if jj<nHex & ii<mHex+shiftNum-1,   %30 degree
                edgek=edgek+1;pointA=point;pointB=(ii+2)*B1+(jj+1)*B2;
HexEdgeAB(edgek,1)=HexIJ2C(ii,jj);HexEdgeAB(edgek,2)=HexIJ2C(ii+2,jj+1);
diffAB=max(abs(HexIm(HexIJ2C(ii+2,jj+1),:)-HexIm(HexIJ2C(ii,jj),:)))/hexScale;
if jj<2 | ii< (3+shiftNum),
HexDeriv(edgek,1)=diffAB;
else
sobDerT=-2*HexIm(HexIJ2C(ii+2,jj+1),:)+2*HexIm(HexIJ2C(ii-2,jj-1),:)+...
    HexIm(HexIJ2C(ii+1,jj),:)-HexIm(HexIJ2C(ii-1,jj-1),:)+...
    HexIm(HexIJ2C(ii+1,jj+1),:)-HexIm(HexIJ2C(ii-1,jj),:);
HexDeriv(edgek,1)=W1*max(abs(sobDerT))/(6*hexScale)+W2*diffAB;
end
            end            
            if jj<(nHex-1),   %90 degree
                edgek=edgek+1;pointA=point;pointB=(ii+1)*B1+(jj+2)*B2;
HexEdgeAB(edgek,1)=HexIJ2C(ii,jj);HexEdgeAB(edgek,2)=HexIJ2C(ii+1,jj+2);
diffAB=max(abs(HexIm(HexIJ2C(ii+1,jj+2),:)-HexIm(HexIJ2C(ii,jj),:)))/hexScale;
if jj<2 | ii< (2+shiftNum) | ii>(mHex+shiftNum-1),
HexDeriv(edgek,1)=diffAB;
else
sobDerT=-2*HexIm(HexIJ2C(ii+1,jj+2),:)+2*HexIm(HexIJ2C(ii-1,jj-2),:)+...
    HexIm(HexIJ2C(ii,jj+1),:)-HexIm(HexIJ2C(ii-1,jj-1),:)+...
    HexIm(HexIJ2C(ii+1,jj+1),:)-HexIm(HexIJ2C(ii,jj-1),:);
HexDeriv(edgek,1)=W1*max(abs(sobDerT))/(6*hexScale)+W2*diffAB;
end
            end       
            if jj<nHex & ii>2+shiftNum,   %150 degree
                edgek=edgek+1;pointA=point;pointB=(ii-1)*B1+(jj+1)*B2;
HexEdgeAB(edgek,1)=HexIJ2C(ii,jj);HexEdgeAB(edgek,2)=HexIJ2C(ii-1,jj+1);
diffAB=max(abs(HexIm(HexIJ2C(ii-1,jj+1),:)-HexIm(HexIJ2C(ii,jj),:)))/hexScale;
if jj<2 | ii>(mHex+shiftNum-2),
HexDeriv(edgek,1)=diffAB;
else
sobDerT=-2*HexIm(HexIJ2C(ii-1,jj+1),:)+2*HexIm(HexIJ2C(ii+1,jj-1),:)+...
    HexIm(HexIJ2C(ii-1,jj),:)-HexIm(HexIJ2C(ii,jj-1),:)+...
    HexIm(HexIJ2C(ii,jj+1),:)-HexIm(HexIJ2C(ii+1,jj),:);
HexDeriv(edgek,1)=W1*max(abs(sobDerT))/(6*hexScale)+W2*diffAB;
end
            end          
        end
    else,%mod(jj,2)==0
        shiftNum=floor(jj/2);
        for ii=(1+shiftNum):(mHex+shiftNum-1),
            point=ii*B1+jj*B2;x=point(1,1);y=point(1,2);
            if jj<nHex & ii<mHex+shiftNum-1,   %30 degree
                edgek=edgek+1;pointA=point;pointB=(ii+2)*B1+(jj+1)*B2;
HexEdgeAB(edgek,1)=HexIJ2C(ii,jj);HexEdgeAB(edgek,2)=HexIJ2C(ii+2,jj+1);
diffAB=max(abs(HexIm(HexIJ2C(ii+2,jj+1),:)-HexIm(HexIJ2C(ii,jj),:)))/hexScale;
if ii< (2+shiftNum),
HexDeriv(edgek,1)=diffAB;
else
sobDerT=-2*HexIm(HexIJ2C(ii+2,jj+1),:)+2*HexIm(HexIJ2C(ii-2,jj-1),:)+...
    HexIm(HexIJ2C(ii+1,jj),:)-HexIm(HexIJ2C(ii-1,jj-1),:)+...
    HexIm(HexIJ2C(ii+1,jj+1),:)-HexIm(HexIJ2C(ii-1,jj),:);
HexDeriv(edgek,1)=W1*max(abs(sobDerT))/(6*hexScale)+W2*diffAB;
end
            end            
            if jj<(nHex-1),   %90 degree
                edgek=edgek+1;pointA=point;pointB=(ii+1)*B1+(jj+2)*B2;
HexEdgeAB(edgek,1)=HexIJ2C(ii,jj);HexEdgeAB(edgek,2)=HexIJ2C(ii+1,jj+2);
diffAB=max(abs(HexIm(HexIJ2C(ii+1,jj+2),:)-HexIm(HexIJ2C(ii,jj),:)))/hexScale;
if jj<3,
HexDeriv(edgek,1)=diffAB;
else
sobDerT=-2*HexIm(HexIJ2C(ii+1,jj+2),:)+2*HexIm(HexIJ2C(ii-1,jj-2),:)+...
    HexIm(HexIJ2C(ii,jj+1),:)-HexIm(HexIJ2C(ii-1,jj-1),:)+...
    HexIm(HexIJ2C(ii+1,jj+1),:)-HexIm(HexIJ2C(ii,jj-1),:);
HexDeriv(edgek,1)=W1*max(abs(sobDerT))/(6*hexScale)+W2*diffAB;
end
            end
            if jj<nHex & ii>1+shiftNum,   %150 degree
                edgek=edgek+1;pointA=point;pointB=(ii-1)*B1+(jj+1)*B2;
HexEdgeAB(edgek,1)=HexIJ2C(ii,jj);HexEdgeAB(edgek,2)=HexIJ2C(ii-1,jj+1);
diffAB=max(abs(HexIm(HexIJ2C(ii-1,jj+1),:)-HexIm(HexIJ2C(ii,jj),:)))/hexScale;
if ii<(2+shiftNum) | ii>(mHex+shiftNum-2),
HexDeriv(edgek,1)=diffAB;
else
sobDerT=-2*HexIm(HexIJ2C(ii-1,jj+1),:)+2*HexIm(HexIJ2C(ii+1,jj-1),:)+...
    HexIm(HexIJ2C(ii-1,jj),:)-HexIm(HexIJ2C(ii,jj-1),:)+...
    HexIm(HexIJ2C(ii,jj+1),:)-HexIm(HexIJ2C(ii+1,jj),:);
HexDeriv(edgek,1)=W1*max(abs(sobDerT))/(6*hexScale)+W2*diffAB;
end
            end
        end
    end%End of mod(jj,2)==1,
end%End of jj=1:nHex,%***End of horizontal derivatives

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
HexDeriv=HexDeriv(1:edgek);HexEdgeAB=HexEdgeAB(1:edgek,:);
HexsrmImGrad8NtimeNNNNNNNNNNNNNNNN=toc