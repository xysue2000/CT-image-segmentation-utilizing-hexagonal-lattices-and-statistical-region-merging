function [imgsSegmentd,nClasses,time,nEdges,szSegmsQs]=...
    srm8Bd(I,Qlevels,g,minSZ,W1,Bd)
tic
[L8Deriv,L8EdgeAB,nEdges]=srmImGrad8N2Vec(I,W1);[~,index]=sort(L8Deriv);
nQ=numel(Qlevels);imgsSegmentd=cell(nQ,1);%hexImgsSegmentd=cell(nQ,1);
m=size(I,1);n=size(I,2);nPixels=m*n;A=[1:nPixels]';
image1=I(:,:,1);image2=I(:,:,2);image3=I(:,:,3);
treerank=zeros(nPixels,1);
szSegms=ones(nPixels,1);imSeg1=image1(:);;imSeg2=image2(:);
imSeg3=image3(:);nClasses=zeros(1,nQ);
logdelta=2*log(6*nPixels);imFinalL8=zeros(size(I));nCl=nPixels;
for Q=Qlevels
    iter=find(Q==Qlevels);
    for i=1:nEdges,
        C1=L8EdgeAB(index(i),1);C2=L8EdgeAB(index(i),2);
        while (A(C1)~=C1 ); C1=A(C1); end
        while (A(C2)~=C2 ); C2=A(C2); end
        % Compute the predicate, region merging test
        dR=(imSeg1(C1)-imSeg1(C2))^2;
        dG=(imSeg2(C1)-imSeg2(C2))^2;dB=(imSeg3(C1)-imSeg3(C2))^2;        
        dev=g^2*logdelta*(1/szSegms(C1)+1/szSegms(C2))/(2*Q);                
        predicat=( (dR<dev) & (dG<dev) & (dB<dev) );               
      if (((C1~=C2)&predicat&(nCl>Bd)) | szSegms(C1)<=minSZ | szSegms(C2)<=minSZ)
            if treerank(C1)>treerank(C2)%Find the new root for both regions
                A(C2) = C1; reg=C1;regNot=C2;
            elseif treerank(C1) < treerank(C2)
                A(C1) = C2; reg=C2;regNot=C1;
            elseif C1 ~= C2
                A(C2) = C1; reg=C1;regNot=C2;
                treerank(C1) = treerank(C1) + 1;
            end
            if C1~=C2% Merge regions
                nreg=szSegms(C1)+szSegms(C2);nCl=nCl-1;
            imSeg1(reg)=(szSegms(C1)*imSeg1(C1)+szSegms(C2)*imSeg1(C2))/nreg;
            imSeg2(reg)=(szSegms(C1)*imSeg2(C1)+szSegms(C2)*imSeg2(C2))/nreg;
            imSeg3(reg)=(szSegms(C1)*imSeg3(C1)+szSegms(C2)*imSeg3(C2))/nreg;
            szSegms(reg)=nreg;nClasses(1,iter)=nClasses(1,iter)+1;
            szSegms(regNot)=0;
            end
        end
    end    
    while 1
        map_ = A(A) ;
        if isequal(map_,A) ; break ; end
        A = map_ ;
    end
imFinalL8(:,:,1)=reshape(imSeg1(A),m,n);
imFinalL8(:,:,2)=reshape(imSeg2(A),m,n);
imFinalL8(:,:,3)=reshape(imSeg3(A),m,n);
imgsSegmentd{iter}=imFinalL8;%maps{iter}=A;
szSegmsOutput=szSegms(:);szSegmsOutput=nonzeros(szSegmsOutput);
szSegmsQs{iter}=szSegmsOutput';
end%end for Q=Qlevels
for t=iter:-1:1,%for t=iter:-1:2,
    tSum=0;
    for j=1:t,
    tSum=tSum+nClasses(1,j);
    end
    nClasses(1,t)=tSum;
end
hhh=8
nClasses=nPixels-nClasses;
time=toc;%End of the function srm8N