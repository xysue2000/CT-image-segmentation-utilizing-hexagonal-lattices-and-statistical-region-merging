function ploc = formPlocVectorFan2paraZ(d,gamma,dploc)

gammaRangeRad = [min(gamma) max(gamma)]*pi/180;
plocRange = d*sin(gammaRangeRad);
plocMin = plocRange(1);plocMax = plocRange(2);
ploc = formVectorCenteredOnZero(dploc,plocMin,plocMax);