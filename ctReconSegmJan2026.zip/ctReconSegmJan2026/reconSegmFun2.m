function [dfNorm1Sq4Sq8Hex,dfNorm2Sq4Sq8Hex,ClSq4Sq8Hex]=reconSegmFun2(Iin,Qlevels);

imL=size(Iin,1);m=imL;n=imL;sic=(imL+1)/2;nQ=length(Qlevels);
AngStep=1;theta=0:AngStep:(180-AngStep);
FanAn=120;totalA=180+FanAn;halfFanAng=FanAn/2;startAng=-halfFanAng;
RotAns=degtorad(startAng:AngStep:(totalA+startAng));
DetAns=-(halfFanAng-AngStep):AngStep:(halfFanAng-AngStep);%Gamma
DetAns=degtorad(DetAns');
SOD=(imL/2)*sqrt(2)/sind(FanAn/2);%SOD: distance of source to center
SOD=ceil(1.2*SOD);SDD=1.6*SOD;voxel=1;%SDD: distance of source to detector
%To compare square lattices with hex lattices fairly, the following
%functiom resample the inputIm to a randomized grid. Then the image on the
%randomized grid is resampled to the sauare lattive and hexagonal lattice
[Svec,Hvec,Av,Bv,Ah,Bh,SqIndVec,SqIJ2C,HexIndVec,HexIJ2C,mHex,...
    nHex,X,Y,B1,B2]=imResample(Iin,imL);
IntMd='pchip';%linear
cutCoef=0.2;%cutCoef=0.2;
Filt='shepp-logan';%ram-lak

disp('Reconstruction by rebinning & sq. lattice & vector input.');
FanCov='minimal';%FanCoverage: cycle or minimal; Default value: cycle 
ParaCov='halfcycle';%ParallelCoverage
%Algorithm for the conversion from fan-beams to parallel-beams 
RsVec=radonVec2(Av,Bv,Svec,imL,theta);%iradon, vectors as the input image
FsVec=para2fanZ(RsVec,SOD,1,1,'arc',FanCov,ParaCov,IntMd);%Sq lattice
PsVec=fan2paraZ(FsVec,SOD,1,1,'arc',IntMd,FanCov,1,ParaCov);%Sq lattice

%Fanbean image reconstruction by rebinning to parallel beams;
%the output tildeSvec is a vector representing an image on a squ. lattice
tildeSvec=iradonVec2(PsVec,theta,Filt,1,IntMd,imL,Bv,Av);%iradon: vector inp
if min(tildeSvec)<0,% cutCoef=0.2;
tildeSvec=max(tildeSvec,cutCoef*min(tildeSvec));    
end
tildeSvecSq=griddata(Bv,Av,tildeSvec,X,Y,'linear');%Resamp to sq im to displ
tildeSvecSq(isnan(tildeSvecSq))=0;%%tildeSvecSq=max(tildeSvecSq,0);

disp('Reconstruction by rebinning & Hex. lattice & vector input.');
%Algorithm for the conversion from fan-beams to parallel-beams
RhVec=radonVec2(Ah,Bh,Hvec,imL,theta);%iradon for hexagonal lattice
FhVec=para2fanZ(RhVec,SOD,1,1,'arc',FanCov,ParaCov,IntMd);%Hex lattice
PhVec=fan2paraZ(FhVec,SOD,1,1,'arc',IntMd,FanCov,1,ParaCov);%Hex lattice

%Fanbean image reconstruction by rebinning to parallel beams;
%the output tildeHvec is a vector representing an image on a hex lattice
tildeHvec=iradonVec2(PhVec,theta,Filt,1,IntMd,imL,Bh,Ah);
if min(tildeHvec)<0,
    tildeHvec=max(tildeHvec,cutCoef*min(tildeHvec));
end
tildeHrVecSq=griddata(Bh,Ah,tildeHvec,X,Y,'linear');%Resampling for display
tildeHrVecSq(isnan(tildeHrVecSq))=0;%%tildeHrVecSq=max(tildeHrVecSq,0);

disp('Pearson correlation coefficient: the bigger the better');
coSqVec=corr2(Svec,tildeSvec);%SqLattice by rebinning
coHexVec=corr2(Hvec,tildeHvec);%HexLattice by rebinning

disp(strcat('CoByRebinOnSqL is:',num2str(coSqVec)));
disp(strcat('CoByRebinOnHexL is:',num2str(coHexVec)));
imN=zeros(imL,imL,3);imN(:,:,1)=tildeSvecSq;%reconSqFM;
imN(:,:,2)=tildeSvecSq;imN(:,:,3)=tildeSvecSq;

imNhexSq=zeros(imL,imL,3);imNhexSq(:,:,1)=tildeHrVecSq;%
imNhexSq(:,:,2)=tildeHrVecSq;imNhexSq(:,:,3)=tildeHrVecSq;

nPixels=length(Hvec);
HexIm=zeros(nPixels,3);
HexIm(:,1)=tildeHvec;HexIm(:,2)=tildeHvec;HexIm(:,3)=tildeHvec;%para
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%inputIm=imN;g=256;minSZ=3;
W1=0.4;%W1=0.4;
g=256;minSZ=3;%Q small few segs
[imgsSegmentd,nClassesL4,time,numEdges,szSegmsQs]...
=srm4N(imN,Qlevels,g,minSZ,W1);%Segmentat. using sq. lattices with 4-connec.
timeOfSegmBy4Conne=time;numEdgesBy4Conne=numEdges;titleFtSz=11;
tI=imgsSegmentd{nQ};IinVec=Iin(:);
df4ConneNorm1=zeros(1,nQ);df4ConneNorm2=zeros(1,nQ);
for k=1:nQ,
    tI=imgsSegmentd{k};tI1d=tI(:,:,1);tI1dVec=tI1d(:);
    df4ConneNorm1(1,k)=norm(tI1dVec-IinVec,1)/length(IinVec);
    df4ConneNorm2(1,k)=norm(tI1dVec-IinVec,2)/length(IinVec);
end

[imgsSegmentd,nClassesL8,time,numEdges,szSegmsQs]...
=srm8N(imN,Qlevels,g,minSZ,W1);%Segmentat. using sq. lattices with 8-connec.
timeOfSegmBy8Conne=time;numEdgesBy8Conne=numEdges;tI=imgsSegmentd{nQ};

df8ConneNorm1=zeros(1,nQ);df8ConneNorm2=zeros(1,nQ);
for k=1:nQ
    tI=imgsSegmentd{k};tI1d=tI(:,:,1);tI1dVec=tI1d(:);
    df8ConneNorm1(1,k)=norm(tI1dVec-IinVec,1)/length(IinVec);
    df8ConneNorm2(1,k)=norm(tI1dVec-IinVec,2)/length(IinVec);
end
[hexImgsSegmentd,nClassesHex,time,numEdges,szSegmsQs]=...
srmHex12Sobel(HexIm,Qlevels,g,minSZ,W1,mHex,nHex,HexIJ2C,B1,B2);%Segmentat. using hex. lattices

for k=1:nQ,
    imFinal=zeros(m,n,3);imFinalHex=hexImgsSegmentd{k};
ImSq1=griddata(Bh,Ah,imFinalHex(:,1),X,Y);
ImSq1(isnan(ImSq1))= 0;
ImSq2=griddata(Bh,Ah,imFinalHex(:,2),X,Y);
ImSq2(isnan(ImSq2))= 0;
ImSq3=griddata(Bh,Ah,imFinalHex(:,3),X,Y);
ImSq3(isnan(ImSq3))= 0;
imFinal(:,:,1)=ImSq1;imFinal(:,:,2)=ImSq2;imFinal(:,:,3)=ImSq3;
imgsSegmentd{k}=imFinal;
end%figure(c+1),imagesc(uint8(imFinal));

dfHexConneNorm1=zeros(1,nQ);dfHexConneNorm2=zeros(1,nQ);
for k=1:nQ,
    tI=hexImgsSegmentd{k};reconstHex1d=tI(:,1);
    dfHexConneNorm1(1,k)=norm(reconstHex1d-Hvec,1)/length(Hvec);
    dfHexConneNorm2(1,k)=norm(reconstHex1d-Hvec,2)/length(Hvec);
end

dfNorm1Sq4Sq8Hex=[df4ConneNorm1;df8ConneNorm1;dfHexConneNorm1];
dfNorm2Sq4Sq8Hex=[df4ConneNorm2;df8ConneNorm2;dfHexConneNorm2];
ClSq4Sq8Hex={nClassesL4;nClassesL8;nClassesHex};