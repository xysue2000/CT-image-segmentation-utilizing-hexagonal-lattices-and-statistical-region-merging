function ploc = formPlocVectorPara2fanZ(m,dploc)
m2cn = floor((m-1)/2);m2cp = floor(m/2);ploc = dploc *(-m2cn:m2cp);